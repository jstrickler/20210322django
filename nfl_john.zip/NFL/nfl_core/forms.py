from django import forms
from .models import Teams, State

class TeamAddForm(forms.ModelForm):
    class Meta:
        model = Teams
        exclude = []


# Create your forms here.


