from django.contrib import admin
# Register your models here.

from .models import Teams, State



admin.site.register(Teams)
admin.site.register(State)
