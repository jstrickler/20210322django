from django.db import models
import logging
# Create your models here.

logging.basicConfig(
    filename='nfl.log',
    level=logging.INFO,
)

# class NflManager(models.Model):
#     def get_teams(self):
#         return self.filter(teams__name__icontain="ra")

class State(models.Model):
    name=models.CharField(max_length=32)

    def __str__(self):
        return self.name

class Teams(models.Model):

    name = models.CharField(max_length=32, unique=True)
    city = models.CharField(max_length=32)
    NFC = 'NFC'
    AFC = 'AFC'
    conference_choice = [
        (NFC,'nfc'),(AFC,'afc'),
    ]
    conference = models.CharField(max_length=3, choices=conference_choice)
    location = models.ForeignKey(State, on_delete = models.CASCADE)

    def __str__(self):
        return '{}, {} ({})'.format(self.name, self.city, self.location)


