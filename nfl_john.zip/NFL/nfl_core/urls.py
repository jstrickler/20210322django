"""
URL Configuration for nfl_core
"""
from django.urls import path
from . import views   # import views from app

app_name = "nfl_core"

urlpatterns = [
    path('', views.home, name='home'),
    path('details/<int:pkid>',views.team_details, name='team_details'),
    path('teamadd',views.team_add,name='team_add')
]