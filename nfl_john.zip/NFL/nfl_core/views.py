from django.http import HttpResponse # only used in class (see comment below)
from django.shortcuts import render, get_object_or_404, redirect
from .models import Teams, State
from .forms import TeamAddForm
# Create your views here.



# example without template (only used in class -- always use templates in real life):
# def home(request):
#     return HttpResponse("Welcome to NFL_core")

# example with template (normal Django approach)
# def home(request):
#     context = { 'message': "Welcome to NFL_core" }
#     return render(request, 'nfl_core/home.html', context)

def home(request):
    teams = Teams.objects.all()
    data = {
        'page_title': 'Welcome to the NFL app for forms',
        'teams': teams,
        'home' : True,
    }
    return render(request,'nfl_core/home.html', data)

def team_details(request,pkid):
    teams = get_object_or_404(Teams,pk=pkid)

    return render(request,'nfl_core/team_details.html',{'teams':teams})

def team_add(request):
    if request.method == 'POST':
        form = TeamAddForm(request.POST)
        if form.is_valid():
            team=Teams()
            team.name=form.cleaned_data.get('name')
            state_id = form.data.get('location')
            team.location = State.objects.get(pk=state_id)
            team.city = form.cleaned_data.get('city')
            team.conference = form.cleaned_data.get('conference')
            team.save()

            context = {
                'page_title': F"Added {team.name}",
                'team':team,
                'added':True
            }
            return render(request, 'nfl_core/team_details.html', context)

        #return render(request, 'nfl_core/home.html', {})
    else:
        form = TeamAddForm()
        context ={
            'page title': 'Add a Dog',
            'form' : form
        }
        return render(request,'nfl_core/team_add.html',context)