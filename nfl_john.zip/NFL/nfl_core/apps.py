from django.apps import AppConfig

class NflCoreConfig(AppConfig):
    name = "nfl_core"
